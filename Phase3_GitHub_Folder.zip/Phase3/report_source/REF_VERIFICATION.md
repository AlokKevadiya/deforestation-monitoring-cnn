# Reference verification log (against live web search)

CONFIRMED = exists exactly (or near-exactly) as cited
CORRECT   = real paper but my metadata was wrong -> fix
REMOVE    = fabricated / cannot verify / wrong target -> delete

## CITED in report (these are the ones that matter — printed in references)
debem2020change        CONFIRMED  Remote Sensing 12(6):901, 2020
jelas2024deforestation CONFIRMED  Front. For. Glob. Change 7:1300060, 2024
naushad2021deep        CONFIRMED  Sensors 21(23):8083, 2021
kanwal2024vgg16shap    CORRECT    Sci Rep 2026, DOI s41598-026-43455-2; AUTHORS were invented -> fix authors+year (key stays but year 2026)
kumaran2024explainable CONFIRMED  BMC Medical Imaging 24:176, 2024 (DOI 10.1186/s12880-024-01345-x)
calix2025toward        CONFIRMED  INMIC 2025; Calix, Hamid, Ali, Syed
sailau2025high         CONFIRMED  INMIC 2025; Sailau, Mohsin, Ali, Syed
khalid2025fruit        CONFIRMED  Engineering Proceedings 87(1):108, 2025
sujon2025accuracy      CORRECT    J Big Data 12:268, 2025; title needs "Business"; authors Mahmud Sujon/Hassan/Choi/Abdus Samad
psistaki2024overview   CONFIRMED  Sustainability 16(14):6089, 2024
decuyper2022continuous CONFIRMED  Remote Sensing of Environment 269:112829, 2022
sarker2022ai           CONFIRMED  SN Computer Science 3(2):158, 2022
campos2020understanding TO-VERIFY Scientific Reports 10:17188, 2020 (seen in earlier search doc 4) -> likely CONFIRMED
abdusalomov2023forest  TO-VERIFY Sensors 23(3):1512, 2023 (seen in search doc 21) -> likely CONFIRMED
ghali2023deep          TO-VERIFY Fire 6(5):192, 2023 (seen doc 25 ref) -> likely CONFIRMED
hashemi2019enlarging   TO-VERIFY J Big Data 6:98, 2019
duong2024automatic     TO-VERIFY Soft Computing 2024
chen2024review         TO-VERIFY lightweight CNN review
santos2025gradcam      TO-VERIFY Grad-CAM caveats 2025
pelosi2025explainability TO-VERIFY Algorithms 18(7):443, 2025
bountos2024deforestation REMOVE   I cited RSE 300:113911 deforestation; real Bountos2024 = Kuro Siwo FLOOD paper. FABRICATED.
rahaman2025lulc        TO-VERIFY ScienceDirect LULC XAI (doc 13 exists, but my author/vol invented) -> verify or REMOVE
andrei2024temperate    CORRECT    paper exists (Eur J Remote Sensing 2024 2367221) but my authors "Andrei/Coca/Datcu" invented -> fix or REMOVE
nasim2025forest        TO-VERIFY Sci Rep 2025 forest fire (doc 25) but my key author "nasim" wrong -> Muksimova et al -> fix or REMOVE

## CITED but lower-stakes (woven in later)
khan2023lightweight    TO-VERIFY Electronics 12(8):1802, 2023
an2024lightweight      TO-VERIFY Front Neurosci 18:1431033, 2024
wang2025plant          TO-VERIFY Remote Sensing 17(4):698, 2025
benfaress2025advancing TO-VERIFY Computers 14(3):88, 2025
kumar2025benchmarking  TO-VERIFY ICET 2025 (instructor) 
alharbi2022review      TO-VERIFY Human Genomics 16:26, 2022
khurana2023natural     TO-VERIFY Multimedia Tools Appl 82:3713, 2023
ismael2021deep         TO-VERIFY Expert Systems Appl 164:114054, 2021
